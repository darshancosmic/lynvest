Lynvest — Personal Finance & Investments (v0.1.3)
==================================================

Lynvest is a 100% offline, privacy-first personal finance tracker for Linux.

QUICK START:
  To run immediately without installing:
    ./lynvest

PERMANENT INSTALL (User-level, no sudo required):
    ./install.sh

UNINSTALL:
    ./uninstall.sh

Support & Sponsorship:
  Ko-fi: https://ko-fi.com/cosmicdarshan
  UPI:   darshancosmic@axl
