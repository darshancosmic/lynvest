Lynvest — Personal Finance & Investments (v0.1.0)
==================================================

Lynvest is a 100% offline, privacy-first personal finance tracker for Linux.

QUICK START:
  To run immediately without installing:
    ./lynvest

PERMANENT INSTALL (User-level, no sudo required):
    ./install.sh

UNINSTALL:
    ./uninstall.sh

Support & Sponsorship:
  Buy Me a Coffee: https://buymeacoffee.com/cosmicdarshan
  Ko-fi:           https://ko-fi.com/cosmicdarshan
