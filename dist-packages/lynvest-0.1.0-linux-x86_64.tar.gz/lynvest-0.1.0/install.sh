#!/usr/bin/env bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/512x512/apps"

echo "Installing Lynvest to $HOME/.local..."
mkdir -p "$BIN_DIR" "$APP_DIR" "$ICON_DIR"

cp "$DIR/lynvest" "$BIN_DIR/lynvest"
chmod +x "$BIN_DIR/lynvest"
cp "$DIR/lynvest.png" "$ICON_DIR/lynvest.png"

# Install desktop file with absolute or PATH exec
sed 's|^Exec=lynvest %U|Exec='"$BIN_DIR"'/lynvest %U|' "$DIR/lynvest.desktop" > "$APP_DIR/lynvest.desktop"
chmod +x "$APP_DIR/lynvest.desktop"

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$APP_DIR" 2>/dev/null || true
fi

echo ""
echo "Lynvest installed successfully!"
echo "You can now run 'lynvest' from terminal (make sure ~/.local/bin is in your PATH)"
echo "or find 'Lynvest' in your application launcher menu."
